<?php 
include 'header.php'; 
?>
		<div class="section section-breadcrumbs">
			<div class="container">
				<div class="row">
					<div class="col-md-6">
						<h1>Contact Us</h1>
					</div>
				</div>
			</div>
		</div>			
        <div class="section">
	    	<div class="container">
	        	<div class="row">
	        		<div class="col-sm-8">
						<h3>Thank you for contacting us!</h3>
						Your message will be sent to a local broker specialist.
					</div>
				</div>
			</div>
			<!-- Google Code for Contact Form Conversion Page -->
			<script type="text/javascript">
				/* <![CDATA[ */
				var google_conversion_id = 944993940;
				var google_conversion_language = "en";
				var google_conversion_format = "2";
				var google_conversion_color = "ffffff";
				var google_conversion_label = "dv3tCJb03lcQlO3NwgM";
				var google_remarketing_only = false;
				/* ]]> */
			</script>
			<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js"></script>
			<noscript>
				<div style="display: inline;">
					<img height="1" width="1" style="border-style:none;" alt="" src="//www.googleadservices.com/pagead/conversion/944993940/?label=dv3tCJb03lcQlO3NwgM&amp;guid=ON&amp;script=0" />
				</div>
			</noscript>
	    </div>
<?php include 'footer.php'; ?>