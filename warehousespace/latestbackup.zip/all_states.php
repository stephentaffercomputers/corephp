<?php include 'header.php'; ?>
		<div class="section section-breadcrumbs">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<h1>States Covered</h1>
					</div>
				</div>
			</div>
		</div>
        
        <div class="section">
	    	<div class="container">
				<div class="row">
					<?php include 'state_list.php' ?>
				</div>
			</div>
		</div>
<?php include 'footer.php'; ?>