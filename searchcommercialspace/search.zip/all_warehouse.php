<?php include 'header.php'; ?>
		<div class="section section-breadcrumbs">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<h1>Warehouse Space for Rent</h1>
					</div>
				</div>
			</div>
		</div>
        
        <div class="section">
	    	<div class="container">
				<div class="row">
					<?php include 'warehouse_list.php' ?>
				</div>
			</div>
		</div>
<?php include 'footer.php'; ?>